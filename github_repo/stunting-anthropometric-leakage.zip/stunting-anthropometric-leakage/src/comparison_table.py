"""
Helper untuk membuat tabel pembanding (comparison table) + grouped bar
chart dari hasil beberapa metode/model/kelompok sekaligus -- komponen
ke-4 yang wajib ada di setiap eksperimen (lihat SKILL.md).

Kenapa fungsi ini ada terpisah: hampir semua eksperimen di proyek ini
pada akhirnya butuh "tabel metode x metrik" + "bar chart metode x
metrik" yang sama bentuknya, entah itu membandingkan model ML, uji
statistik antar kelompok, atau kondisi sebelum/sesudah. Daripada
menulis ulang logika ini setiap kali, pakai fungsi ini supaya bentuk
tabel & gambar konsisten lintas eksperimen.
"""
import os
import sys

import matplotlib.pyplot as plt
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
from plot_style import apply_style, annotate_source, COLORBLIND_SAFE_PALETTE  # noqa: E402


def build_comparison(results: dict, out_csv: str, out_png: str,
                      title: str = "Perbandingan Metode",
                      value_label: str = "Nilai",
                      higher_is_better: bool = True) -> pd.DataFrame:
    """
    results: dict bertingkat, mis.
        {
            "Baseline (mayoritas)": {"AUC": 0.50, "Sensitivitas": 0.0, "Spesifisitas": 1.0},
            "Regresi Logistik":     {"AUC": 0.71, "Sensitivitas": 0.62, "Spesifisitas": 0.68},
            "Random Forest":        {"AUC": 0.79, "Sensitivitas": 0.70, "Spesifisitas": 0.74},
        }
    out_csv / out_png: path keluaran tabel & gambar.
    higher_is_better: menentukan bunyi catatan cara-baca di bawah grafik
        ("tertinggi = terbaik" vs "terendah = terbaik"); set False untuk
        metrik seperti p-value atau error rate.

    Mengembalikan DataFrame yang sudah disimpan (untuk dipakai lagi kalau perlu).
    """
    apply_style()

    df = pd.DataFrame(results).T
    df.index.name = "Metode"
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    df.to_csv(out_csv)

    # Grouped bar chart: satu grup batang per metode, satu warna per metrik.
    fig, ax = plt.subplots(figsize=(max(6, 1.4 * len(df)), 4.5))
    n_metrics = len(df.columns)
    x = range(len(df))
    width = 0.8 / max(n_metrics, 1)

    for i, col in enumerate(df.columns):
        offset = (i - (n_metrics - 1) / 2) * width
        ax.bar([xi + offset for xi in x], df[col].values, width=width,
               label=col, color=COLORBLIND_SAFE_PALETTE[i % len(COLORBLIND_SAFE_PALETTE)])

    ax.set_xticks(list(x))
    ax.set_xticklabels(df.index, rotation=15, ha="right")
    ax.set_ylabel(value_label)
    ax.set_title(title)
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0))

    best_note = "tertinggi = terbaik" if higher_is_better else "terendah = terbaik"
    annotate_source(fig, f"Catatan: {best_note}. Lihat tabel CSV untuk angka pasti.")

    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png)
    plt.close(fig)

    return df


def build_forest_plot(estimates: dict, out_csv: str, out_png: str,
                       title: str = "Perbandingan Effect Size",
                       null_value: float = 1.0,
                       log_scale: bool = True) -> pd.DataFrame:
    """
    Forest plot untuk membandingkan effect size + confidence interval (odds
    ratio, hazard ratio, koefisien regresi, dst.) antar model/variabel --
    JANGAN pakai build_comparison() untuk kasus ini: OR (mis. 0.4-0.7) dan
    p-value (mis. 0.0001) berada di skala yang jauh berbeda, sehingga kalau
    dipaksa jadi bar chart satu sumbu-y, batang p-value jadi tidak kelihatan
    sama sekali dan grafiknya menyesatkan. Forest plot (titik + garis CI,
    satu baris per model/variabel) adalah cara standar di literatur
    epidemiologi untuk kasus ini, dan tidak punya masalah skala tsb karena
    p-value ditaruh sebagai teks di tabel, bukan ikut dibatang-grafikkan.

    estimates: dict, mis.
        {
            "Crude (unadjusted)": {"estimate": 2.49, "ci_low": 1.62, "ci_high": 3.83, "p": 0.00004},
            "Adjusted (umur + pendidikan ibu)": {"estimate": 2.10, "ci_low": 1.31, "ci_high": 3.37, "p": 0.002},
        }
        Pastikan arah/koding variabel (mis. kategori referensi) SAMA antara
        baris crude & adjusted -- kalau tidak, OR bisa kelihatan kontradiktif
        padahal cuma beda arah pembanding. Sebutkan kategori referensi di
        judul atau README.
    null_value: garis referensi "tidak ada efek" (1.0 untuk OR/HR, 0.0 untuk
        koefisien regresi linear).
    log_scale: pakai sumbu-x logaritmik (default True, standar untuk OR/HR
        supaya jarak visual OR=0.5 dan OR=2 terlihat setara/simetris).
    """
    apply_style()

    df = pd.DataFrame(estimates).T
    df.index.name = "Model/Variabel"
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    df.to_csv(out_csv)

    # Beri ruang ekstra di kanan supaya teks anotasi (estimate/CI/p) tidak
    # terpotong atau tertindih tick terakhir.
    data_min = min(df["ci_low"].min(), null_value)
    data_max = max(df["ci_high"].max(), null_value)
    xlim_low = data_min * 0.85 if data_min > 0 else data_min - abs(data_max) * 0.1
    xlim_high = data_max * 2.2  # ruang untuk teks di sisi kanan tiap titik

    fig, ax = plt.subplots(figsize=(8.5, max(2.2, 0.7 * len(df) + 1)))
    y_pos = range(len(df))

    def _fmt_p(p):
        if p is None or pd.isna(p):
            return ""
        return f"p<0.001" if p < 0.001 else f"p={p:.3f}"

    for i, (label, row) in enumerate(df.iterrows()):
        color = COLORBLIND_SAFE_PALETTE[i % len(COLORBLIND_SAFE_PALETTE)]
        ax.plot([row["ci_low"], row["ci_high"]], [i, i], color=color, linewidth=2, zorder=2)
        ax.scatter([row["estimate"]], [i], color=color, s=70, zorder=3)
        p_txt = f", {_fmt_p(row.get('p'))}" if "p" in row else ""
        ax.text(row["ci_high"], i, f"  {row['estimate']:.2f} [{row['ci_low']:.2f}–{row['ci_high']:.2f}]{p_txt}",
                va="center", fontsize=9)

    ax.axvline(null_value, color="#888888", linestyle="--", linewidth=1, zorder=1)
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(df.index)
    ax.invert_yaxis()
    ax.set_xlim(xlim_low, xlim_high)
    if log_scale:
        ax.set_xscale("log")
        # Ticks eksplisit dari angka "rapi" di rentang data + null_value,
        # dengan label desimal biasa -- matplotlib default log-tick locator
        # sering membuat label berdempetan/tumpang tindih pada rentang sempit.
        from matplotlib.ticker import FixedLocator, NullLocator, ScalarFormatter
        candidates = [0.1, 0.2, 0.25, 0.33, 0.5, 0.67, 0.75, 1, 1.5, 2, 2.5, 3, 4, 5, 6, 7, 8, 10, 15, 20, 30]
        ticks = sorted(set([t for t in candidates if data_min * 0.9 <= t <= data_max * 1.1] + [null_value]))
        if len(ticks) >= 2:
            ax.xaxis.set_major_locator(FixedLocator(ticks))
            ax.xaxis.set_minor_locator(NullLocator())
            ax.xaxis.set_major_formatter(ScalarFormatter())
    ax.set_xlabel(f"Estimate (garis putus-putus = tidak ada efek, di {null_value})")
    ax.set_title(title)

    annotate_source(fig, "Titik = estimate, garis = 95% CI. Lihat tabel CSV untuk angka & p-value pasti.")

    os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
    fig.savefig(out_png)
    plt.close(fig)

    return df


if __name__ == "__main__":
    # Contoh pakai (hapus/ganti saat dipakai di eksperimen sungguhan)
    demo = {
        "Baseline (mayoritas)": {"AUC": 0.50, "Sensitivitas": 0.0, "Spesifisitas": 1.0},
        "Regresi Logistik": {"AUC": 0.71, "Sensitivitas": 0.62, "Spesifisitas": 0.68},
        "Random Forest": {"AUC": 0.79, "Sensitivitas": 0.70, "Spesifisitas": 0.74},
    }
    build_comparison(demo, "demo_out/comparison.csv", "demo_out/comparison.png",
                      title="Contoh: Perbandingan Model (DATA DEMO)")

    demo_forest = {
        "Crude (unadjusted)": {"estimate": 2.49, "ci_low": 1.62, "ci_high": 3.83, "p": 0.00004},
        "Adjusted (umur + pendidikan ibu)": {"estimate": 2.10, "ci_low": 1.31, "ci_high": 3.37, "p": 0.002},
    }
    build_forest_plot(demo_forest, "demo_out/forest.csv", "demo_out/forest.png",
                       title="Contoh: OR Sanitasi -> Stunting, Crude vs Adjusted (DATA DEMO)")

    print("Demo comparison + forest plot dibuat di demo_out/")
