# Data (not included)

This folder must contain two files before running the analysis:

1. `SKI_2023_Balita_0-59_Bulan_asli_labels.xlsx` — the child (0–59 months) module of the
   2023 Indonesian Health Survey (Survei Kesehatan Indonesia, SKI 2023). The microdata are owned by the
   Health Development Policy Agency (BKPK), Ministry of Health of the Republic of Indonesia, and can be
   requested through BKPK's official data-request service. They are not redistributed here.
2. `lenanthro.txt` — the WHO Child Growth Standards length/height-for-age LMS table
   (columns: sex, age [days], l, m, s, loh), distributed with the WHO growth-standard software
   (WHO Anthro / igrowup macros and the WHO `anthro` R package).
