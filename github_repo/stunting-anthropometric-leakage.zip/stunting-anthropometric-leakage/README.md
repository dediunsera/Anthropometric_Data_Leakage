# Anthropometric data leakage in child stunting prediction (SKI 2023)

Analysis code for the article *"Anthropometric data leakage inflates machine learning performance in child
stunting prediction"* (A. D. Jubaedi, P. N. Andono, N. Rijati, A. Z. Fanani; submitted to IJECE).

Stunting is defined from height, age, and sex (height-for-age z-score < −2 SD, WHO 2006). Many machine
learning studies nevertheless use current height and weight as predictors and report near-perfect accuracy.
This repository reproduces a controlled experiment on 84,205 children aged 0–59 months from the 2023
Indonesian Health Survey that quantifies this target leakage.

## Design
| Scenario | Predictors |
|---|---|
| B | 119 upstream determinants (child, maternal, perinatal, feeding, WASH, housing, access, region) |
| A1 | B + current weight (proxy leakage) |
| A2 | B + current weight, length/height, MUAC, waist circumference (mimics prior studies) |
| L0 | Current length/height + age + sex only (pure target leakage) |

Models: logistic regression, random forest, histogram gradient boosting (scikit-learn). Household-grouped
stratified 80/20 split, all pre-processing inside pipelines, 1,000-sample bootstrap CIs, paired bootstrap ΔAUC,
household-grouped 5-fold CV, and permutation importance. Random seed 42.

## Main results (hold-out AUC, 16,841 children from 15,060 unseen households)
| Scenario | LR | RF | HGB |
|---|---|---|---|
| B | 0.656 | 0.654 | 0.670 |
| A1 | 0.803 | 0.759 | 0.825 |
| A2 | 0.951 | 0.862 | 0.998 |
| L0 | 0.910 | 0.999 | 0.999 |

Full metrics are in [`results/metrics.csv`](results/metrics.csv).

## Repository layout
```
src/run_experiment.py          full pipeline (outcome, feature sets, training, evaluation, figures)
src/who_haz.py                 WHO length/height-for-age z-score (LMS method)
src/make_manuscript_figures.py figures with English labels used in the article
src/plot_style.py, src/comparison_table.py   plotting helpers
results/                       all result tables, data flow, exclusion list, configuration
figures/                       all figures
data/README.md                 how to obtain the (non-redistributable) input data
```

## Reproduce
```bash
pip install -r requirements.txt
# place the SKI 2023 child file and lenanthro.txt in data/ (see data/README.md)
python src/run_experiment.py          # ~20 min on one CPU core
python src/make_manuscript_figures.py
```

## Data availability
The SKI 2023 microdata belong to the Health Development Policy Agency (BKPK), Ministry of Health of the
Republic of Indonesia, and are available from BKPK upon request; they are not included in this repository.

## License
Code: MIT. See `CITATION.cff` for citation information.
